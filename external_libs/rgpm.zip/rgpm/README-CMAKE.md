On mac to run locally the following libraries are needed
```bash
brew install boost 
brew install tbb
brew install gsl
brew install google-sparsehash
```

To compile with cmake on local run the following but read ahead if you're interested in setting up xcode.
```
num_jobs=1
build_type=Release
build_dir=build
cmake -DCMAKE_BUILD_TYPE=$build_type -S . -B ./$build_dir
cmake --build ./$build_dir --target all -- -j $num_jobs
mv ./$build_dir/tradicional ./
```

On linux you only need conda and gcc, this script creates the environment if it doesn't exist and activates it before compiling
If you already have an environment named ripple please modify it to match the env created within the script or delete the existing environment 
```bash
./compile.sh 
```

compile.sh will create an executable in the project directory
To run an application
```bash
./tradicional -i data/yeastbigcomp-sl.gph -o dmp -p 3 -s 10000 -c config.txt -l debug
```
you can replace G.lg with of the graphs from ../../data/
 
On your local machine to create an xcode project  
```bash
cmake -G "Xcode" ./
```
open the created xcodeproj in xcode, you'll find the target tradicional which you can run and debug now.