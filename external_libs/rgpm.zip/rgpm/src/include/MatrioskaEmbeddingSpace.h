#ifndef MATRIOSKAEMBEDDINGSPACE_H
#define MATRIOSKAEMBEDDINGSPACE_H

#include "BasicEmbeddingSpace.h"
#include "reservoir.h"
#include "TourStats.h"
#include <iostream>
#include <tbb/concurrent_hash_map.h>
#include <tbb/concurrent_queue.h>
#include <tbb/recursive_mutex.h>
#include <tbb/parallel_for.h>
#include <tbb/task_group.h>
#include <tbb/task_scheduler_init.h>
#include <tbb/blocked_range.h>
#include <tbb/parallel_reduce.h>
#include <array>
#include <chrono>
#include <sstream>      // std::stringstream
#include <bitset>
#include <boost/dynamic_bitset.hpp>

template <class T, class A>
class EmbeddingSpaceMSK:public EmbeddingSpace<T,A> {

	public:
	boost::dynamic_bitset<> lsn, lrw, lnext;
	Graph *g_complete;
	std::vector<std::vector<int>> partitionNeighborhood;
	std::vector<uint> partitionMap;
	std::vector<uint> partitionLayerMap;
	std::vector<std::unordered_set<int>> partitions;
	std::vector<double> degreeEstimateAux;
	std::vector<double> countEstimateAux;
	std::vector<double> countEstimate;
	int nthreads;	
	int numInitialSuperNodePartitions;
	
	//these vectors use a matrix represetation (numPartitions x numPartitions)
	std::vector<double> degreeEstimatePartial; // it keeps the degree beteween two partitions
	std::vector<reservoir<T>> rs;
	typename std::unordered_map<size_t, std::pair<double,reservoir<T>>> partitionRelationMap; // it keeps the degree beteween two partitions

	static const unsigned int maxlevelexp = 1000000;
	static const unsigned int MAXCORE = 10;
	static const unsigned int NUM_INITIAL_PARTITIONS = 1;
	static constexpr double supernodefraction = 1.;

	EmbeddingSpaceMSK(int , Graph *); 
	EmbeddingSpaceMSK(int , Graph *, std::string); 
	EmbeddingSpaceMSK(int , Graph *, std::string, int); 

	void run_rw();
	std::vector<TourStats> getGroupStats(T&, int);
	TourStats2<T> groupEstimateUsingTour(uint, uint, int);
	TourStats2<T> groupEstimateAllTours(uint, uint, int);
	void groupEstimateUsingBruteForceUtil(T&, int, uint, std::unordered_set<int> &, TourStats2<T> &);
	TourStats2<T> groupEstimateUsingBruteForce(uint, uint);

	//bool isSubset(boost::dynamic_bitset<> &, std::vector<int> &);
	bool isInPreviousLevels(uint, std::vector<int> &);
	uint getGraphLayerEdges(boost::dynamic_bitset<> &);
	ModSet getModificationsToPreviousLevels(T&, uint);
	ModSet getModificationsToPreviousLevels(T&, uint, ModSet &);
	ModSet getModificationsToLevel(T&, uint);
	ModSet getModificationsToLevel(T&, uint, ModSet &);
	void updateGroupStats(T &, T &, TourStats2<T> &);

	void initAllLevels(T &, Graph *);
	void initPartitionLayers(T &, Graph *);
	std::unordered_set<int> buildNextPartition(int nodeRoot, std::vector<int> &coreness, boost::dynamic_bitset<> &lroot, Graph *g);
	int connectNodesInPartitions(Graph *, T &);
	uint getGraphOutLevelEdges(boost::dynamic_bitset<> &);
	uint getGraphInLevelEdges(boost::dynamic_bitset<> &);
	uint getGraphInLevelEdges(std::unordered_set<int> &);
	uint getGraphInLevelEdges(boost::dynamic_bitset<> &, int);
	uint getGraphInLevelEdges(std::unordered_set<int> &, int);
	double getNodeCost(boost::dynamic_bitset<> &, int, int);
	T getRandomEmbeddingInLevel(uint);
	int countNodesInPartition(uint partition_idx);
	void getPartitionInfo(Graph *);	
	void checkPartitionConnection();
	inline size_t getMatrixPositionInArray(int r, int c) {
		//return (c*(c-1))/2 + r;
		/*size_t seed=0;
		boost::hash_combine(seed,  r * 15487469);
		boost::hash_combine(seed,  c * 2654435761);
		return seed;*/

		return 0.5*(r+c)*(r+c+1)+c;
	}

	bool insertPartitionRelation(size_t idx, double d, reservoir<T> &rv) {
		typename std::unordered_map<size_t, std::pair<double,reservoir<T>>>::iterator it = partitionRelationMap.find(idx);
		if (it!=partitionRelationMap.end()) { 
			std::cout << "error: trying to insert same partition relation again!" << std::endl;
			exit(1);	
		}
		std::pair<double,reservoir<T>> p(d, rv);
		partitionRelationMap.insert(std::pair<size_t, std::pair<double,reservoir<T>>> (idx, p));
		return true;
	}
	void updatePartitionRelationReservoir(size_t idx, T& e) {
		typename std::unordered_map<size_t, std::pair<double,reservoir<T>>>::iterator it = partitionRelationMap.find(idx);
                if (it==partitionRelationMap.end()) { 
			std::pair<double,reservoir<T>> p (0, reservoir<T>());
			partitionRelationMap.insert(std::pair<size_t, std::pair<double,reservoir<T>>> (idx, p));
		}
		it = partitionRelationMap.find(idx);
		if (it==partitionRelationMap.end()) { 
			std::cout << "error: trying to insert an element in the reservoir of partition relation!" << std::endl;
			exit(1);	
		}
		it->second.second.insert(e);
	}
	void setDegreePartitionRelation(size_t idx, double d) {
		typename std::unordered_map<size_t, std::pair<double,reservoir<T>>>::iterator it = partitionRelationMap.find(idx);
                if (it==partitionRelationMap.end()) {
			std::pair<double,reservoir<T>> p (d, reservoir<T>());
			partitionRelationMap.insert(std::pair<size_t, std::pair<double,reservoir<T>>> (idx, p));
			return;
		}
		it->second.first = d;
	}
	std::pair<double,bool> getDegreePartitionRelation(size_t idx) {
		typename std::unordered_map<size_t, std::pair<double,reservoir<T>>>::iterator it = partitionRelationMap.find(idx);
                if (it==partitionRelationMap.end()) return std::pair<double, bool> (0., false);
		return std::pair<double, bool> (it->second.first, true);
	}
	std::pair<reservoir<T>, bool> getReservoirPartitionRelation(size_t idx) {
		typename std::unordered_map<size_t, std::pair<double,reservoir<T>>>::iterator it = partitionRelationMap.find(idx);
                if (it==partitionRelationMap.end()) return std::pair<reservoir<T>, bool> (reservoir<T>(), false);
		return std::pair<reservoir<T>, bool> (it->second.second, true);
	}
	void removePartitionRelation(size_t idx) {
		typename std::unordered_map<size_t, std::pair<double,reservoir<T>>>::iterator it = partitionRelationMap.find(idx);
                if (it!=partitionRelationMap.end()) partitionRelationMap.erase(it);

	}
};


#endif
