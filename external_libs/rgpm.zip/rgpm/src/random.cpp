#include "random.h"

thread_local sfmt_t* Randness::sfmt_pt = NULL;
thread_local pcg32_random_t* Randness::pcg_pt = NULL;
thread_local boost::mt19937* Randness::mt_pt = NULL;

//int Randness::seed = std::chrono::system_clock::now().time_since_epoch().count();
int Randness::seed = 0;

Randness::Randness() {
}

