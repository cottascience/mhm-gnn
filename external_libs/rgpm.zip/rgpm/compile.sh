#!/bin/zsh
num_jobs=${SLURM_CPUS_PER_TASK:-1}
build_type=${1:-Release}
build_dir=${2:-build}
echo "Building $build_type (1) in directory $build_dir (2) with $num_jobs cpus"

# Activate Conda environment
eval "$(conda shell.zsh hook)"
conda activate rgpm

# Create environment if not exists
if [[ $? != 0 ]]
then
    conda create --name rgpm -c conda-forge -c anaconda -c statiskit python=3 tbb gsl sparsehash boost=1.68.0 tbb-devel libboost-dev=1.68.0 cmake redis redis-py pandas tqdm
    conda activate rgpm
fi

# Cmake
cmake -DCMAKE_BUILD_TYPE=$build_type -S . -B ./$build_dir
cmake --build ./$build_dir --target all -- -j $num_jobs

# Get executable in desired directory
mv ./$build_dir/tradicional ./
